# Topsis-Nihar-10155792

This package implements TOPSIS (Technique for Order Preference by Similarity to Ideal Solution).

## Install
```bash
pip install Topsis-Nihar-10155792
